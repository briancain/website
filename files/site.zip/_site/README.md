# briancain.net

Go to www.briancain.net to view the website.

## Setup

```
gem install jekyll
jekyll serve
```
